tinyMCE.addI18n('bs.template_dlg',{
title:"Predlo\u0161ci",
label:"Predlo\u017Eak",
desc_label:"Opis",
desc:"Umetni sadr\u017Eaj predlo\u0161ka",
select:"Odaberite predlo\u017Eak",
preview:"Prikaz",
warning:"Upozorenje: Nadopuna predlo\u0161ka novim mo\u017Ee uzrokovati gubitak podataka.",
mdate_format:"%d.%m.%Y %H:%M:%S",
cdate_format:"%d.%m.%Y %H:%M:%S",
months_long:"sije\u010Danj,velja\u010Da,o\u017Eujak,travanj,svibanj,lipanj,srpanj,kolovoz,rujan,listopad,studeni,prosinac",
months_short:"sij,velj,o\u017Eu,tra,svi,lip,srp,kol,ruj,lis,stu,pro",
day_long:"nedjelja,ponedjeljak,utorak,srijeda,\u010Detvrtak,petak,subota,nedjelja",
day_short:"ned,pon,uto,sri,\u010Det,pet,sub,ned"
});